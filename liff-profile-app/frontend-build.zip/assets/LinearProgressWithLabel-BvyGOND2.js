import{a as R,g as M,r as q,u as D,i as O,j as n,s as v,c as w,b as o,d as z,m as y,aj as f,ak as N,al as A,am as L,an as j,ag as T,v as C,T as S}from"./index-B0TPX7AG.js";function U(a){return R("MuiLinearProgress",a)}M("MuiLinearProgress",["root","colorPrimary","colorSecondary","determinate","indeterminate","buffer","query","dashed","dashedColorPrimary","dashedColorSecondary","bar","bar1","bar2","barColorPrimary","barColorSecondary","bar1Indeterminate","bar1Determinate","bar1Buffer","bar2Indeterminate","bar2Buffer"]);const x=4,$=j`
  0% {
    left: -35%;
    right: 100%;
  }

  60% {
    left: 100%;
    right: -90%;
  }

  100% {
    left: 100%;
    right: -90%;
  }
`,K=typeof $!="string"?L`
        animation: ${$} 2.1s cubic-bezier(0.65, 0.815, 0.735, 0.395) infinite;
      `:null,P=j`
  0% {
    left: -200%;
    right: 100%;
  }

  60% {
    left: 107%;
    right: -8%;
  }

  100% {
    left: 107%;
    right: -8%;
  }
`,E=typeof P!="string"?L`
        animation: ${P} 2.1s cubic-bezier(0.165, 0.84, 0.44, 1) 1.15s infinite;
      `:null,k=j`
  0% {
    opacity: 1;
    background-position: 0 -23px;
  }

  60% {
    opacity: 0;
    background-position: 0 -23px;
  }

  100% {
    opacity: 1;
    background-position: -200px -23px;
  }
`,G=typeof k!="string"?L`
        animation: ${k} 3s infinite linear;
      `:null,V=a=>{const{classes:r,variant:e,color:t}=a,l={root:["root",`color${o(t)}`,e],dashed:["dashed",`dashedColor${o(t)}`],bar1:["bar","bar1",`barColor${o(t)}`,(e==="indeterminate"||e==="query")&&"bar1Indeterminate",e==="determinate"&&"bar1Determinate",e==="buffer"&&"bar1Buffer"],bar2:["bar","bar2",e!=="buffer"&&`barColor${o(t)}`,e==="buffer"&&`color${o(t)}`,(e==="indeterminate"||e==="query")&&"bar2Indeterminate",e==="buffer"&&"bar2Buffer"]};return z(l,U,r)},B=(a,r)=>a.vars?a.vars.palette.LinearProgress[`${r}Bg`]:a.palette.mode==="light"?N(a.palette[r].main,.62):A(a.palette[r].main,.5),W=v("span",{name:"MuiLinearProgress",slot:"Root",overridesResolver:(a,r)=>{const{ownerState:e}=a;return[r.root,r[`color${o(e.color)}`],r[e.variant]]}})(y(({theme:a})=>({position:"relative",overflow:"hidden",display:"block",height:4,zIndex:0,"@media print":{colorAdjust:"exact"},variants:[...Object.entries(a.palette).filter(f()).map(([r])=>({props:{color:r},style:{backgroundColor:B(a,r)}})),{props:({ownerState:r})=>r.color==="inherit"&&r.variant!=="buffer",style:{"&::before":{content:'""',position:"absolute",left:0,top:0,right:0,bottom:0,backgroundColor:"currentColor",opacity:.3}}},{props:{variant:"buffer"},style:{backgroundColor:"transparent"}},{props:{variant:"query"},style:{transform:"rotate(180deg)"}}]}))),X=v("span",{name:"MuiLinearProgress",slot:"Dashed",overridesResolver:(a,r)=>{const{ownerState:e}=a;return[r.dashed,r[`dashedColor${o(e.color)}`]]}})(y(({theme:a})=>({position:"absolute",marginTop:0,height:"100%",width:"100%",backgroundSize:"10px 10px",backgroundPosition:"0 -23px",variants:[{props:{color:"inherit"},style:{opacity:.3,backgroundImage:"radial-gradient(currentColor 0%, currentColor 16%, transparent 42%)"}},...Object.entries(a.palette).filter(f()).map(([r])=>{const e=B(a,r);return{props:{color:r},style:{backgroundImage:`radial-gradient(${e} 0%, ${e} 16%, transparent 42%)`}}})]})),G||{animation:`${k} 3s infinite linear`}),F=v("span",{name:"MuiLinearProgress",slot:"Bar1",overridesResolver:(a,r)=>{const{ownerState:e}=a;return[r.bar,r.bar1,r[`barColor${o(e.color)}`],(e.variant==="indeterminate"||e.variant==="query")&&r.bar1Indeterminate,e.variant==="determinate"&&r.bar1Determinate,e.variant==="buffer"&&r.bar1Buffer]}})(y(({theme:a})=>({width:"100%",position:"absolute",left:0,bottom:0,top:0,transition:"transform 0.2s linear",transformOrigin:"left",variants:[{props:{color:"inherit"},style:{backgroundColor:"currentColor"}},...Object.entries(a.palette).filter(f()).map(([r])=>({props:{color:r},style:{backgroundColor:(a.vars||a).palette[r].main}})),{props:{variant:"determinate"},style:{transition:`transform .${x}s linear`}},{props:{variant:"buffer"},style:{zIndex:1,transition:`transform .${x}s linear`}},{props:({ownerState:r})=>r.variant==="indeterminate"||r.variant==="query",style:{width:"auto"}},{props:({ownerState:r})=>r.variant==="indeterminate"||r.variant==="query",style:K||{animation:`${$} 2.1s cubic-bezier(0.65, 0.815, 0.735, 0.395) infinite`}}]}))),_=v("span",{name:"MuiLinearProgress",slot:"Bar2",overridesResolver:(a,r)=>{const{ownerState:e}=a;return[r.bar,r.bar2,r[`barColor${o(e.color)}`],(e.variant==="indeterminate"||e.variant==="query")&&r.bar2Indeterminate,e.variant==="buffer"&&r.bar2Buffer]}})(y(({theme:a})=>({width:"100%",position:"absolute",left:0,bottom:0,top:0,transition:"transform 0.2s linear",transformOrigin:"left",variants:[...Object.entries(a.palette).filter(f()).map(([r])=>({props:{color:r},style:{"--LinearProgressBar2-barColor":(a.vars||a).palette[r].main}})),{props:({ownerState:r})=>r.variant!=="buffer"&&r.color!=="inherit",style:{backgroundColor:"var(--LinearProgressBar2-barColor, currentColor)"}},{props:({ownerState:r})=>r.variant!=="buffer"&&r.color==="inherit",style:{backgroundColor:"currentColor"}},{props:{color:"inherit"},style:{opacity:.3}},...Object.entries(a.palette).filter(f()).map(([r])=>({props:{color:r,variant:"buffer"},style:{backgroundColor:B(a,r),transition:`transform .${x}s linear`}})),{props:({ownerState:r})=>r.variant==="indeterminate"||r.variant==="query",style:{width:"auto"}},{props:({ownerState:r})=>r.variant==="indeterminate"||r.variant==="query",style:E||{animation:`${P} 2.1s cubic-bezier(0.165, 0.84, 0.44, 1) 1.15s infinite`}}]}))),H=q.forwardRef(function(r,e){const t=D({props:r,name:"MuiLinearProgress"}),{className:l,color:c="primary",value:u,valueBuffer:p,variant:i="indeterminate",...h}=t,d={...t,color:c,variant:i},b=V(d),I=O(),m={},g={bar1:{},bar2:{}};if((i==="determinate"||i==="buffer")&&u!==void 0){m["aria-valuenow"]=Math.round(u),m["aria-valuemin"]=0,m["aria-valuemax"]=100;let s=u-100;I&&(s=-s),g.bar1.transform=`translateX(${s}%)`}if(i==="buffer"&&p!==void 0){let s=(p||0)-100;I&&(s=-s),g.bar2.transform=`translateX(${s}%)`}return n.jsxs(W,{className:w(b.root,l),ownerState:d,role:"progressbar",...m,ref:e,...h,children:[i==="buffer"?n.jsx(X,{className:b.dashed,ownerState:d}):null,n.jsx(F,{className:b.bar1,ownerState:d,style:g.bar1}),i==="determinate"?null:n.jsx(_,{className:b.bar2,ownerState:d,style:g.bar2})]})});function Q(a,r,e){return T(a,-r,e)}const Y=a=>{const{value:r,consumed:e,goal:t,unit:l,isMaxGoal:c,color:u}=a,p=Math.min(r,100),i=e??0,h=t??0;return n.jsxs(C,{sx:{display:"flex",alignItems:"center"},children:[n.jsx(C,{sx:{width:"100%",mr:1},children:n.jsx(H,{variant:"determinate",value:p,color:r>100&&!c?"warning":r>100&&c?"error":"primary",sx:{"& .MuiLinearProgress-bar":{backgroundColor:u,transition:"transform 1.2s ease-in-out"},height:8,borderRadius:4}})}),n.jsx(C,{sx:{minWidth:120,textAlign:"right"},children:n.jsx(S,{variant:"body2",color:"text.secondary",children:`${i}${l} / ${c?"ไม่เกิน ":""}${h}${l}`})})]})};export{Y as L,H as a,Q as s};
